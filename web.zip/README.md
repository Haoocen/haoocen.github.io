# haoocen.github.io

- This is everything of my personal website [haocenj.com](http://haocenj.com) which is made using Bootstrap 3.
- I adapted a template from [Start Bootstrap](https://startbootstrap.com/template-overviews/resume/).

